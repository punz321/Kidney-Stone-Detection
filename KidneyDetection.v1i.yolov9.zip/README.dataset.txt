# Kidney detection > 2024-05-01 6:58pm
https://universe.roboflow.com/kidney-627pn/kidney-detection

Provided by a Roboflow user
License: CC BY 4.0

